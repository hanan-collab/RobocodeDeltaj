package jab.module; 

import robocode.Bullet; 

/**
 * Bullet info
 * 
 * @author jab
 */
public  class  BulletInfo {
	

	public Bullet bullet;

	
	public int timeFire;

	
	public String targeting;

	
	public String toName;


}
